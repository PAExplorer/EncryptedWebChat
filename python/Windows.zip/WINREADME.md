This is the windows executable build.
In my testing this works when paired with a server running the script in python
The executable is dependent on those other files in it's directory.

As it's source code this program is distributed under the GNU 3.0 license and all that it entails.
Feel free to build it yourself if you don't trust this build. This executable was created using:

python3 -m PyInstaller --onefile .\ClientChat.py